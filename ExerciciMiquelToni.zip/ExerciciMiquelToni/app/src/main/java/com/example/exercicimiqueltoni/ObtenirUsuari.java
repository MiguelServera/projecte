package com.example.exercicimiqueltoni;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ObtenirUsuari extends AppCompatActivity implements View.OnClickListener{
    DBInterface bd;
    Button btnConsulta;
    EditText editId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obtenir);
        bd = new DBInterface(this);
        btnConsulta = (Button) findViewById(R.id.btnConsulta);
        btnConsulta.setOnClickListener(this);
        editId = (EditText) findViewById((R.id.editText));
    }

    public void onClick(View v) {
        if (v == btnConsulta) {
            Cursor c;
            bd = new DBInterface(this.getApplicationContext());
            bd.obre();
            long id = Long.parseLong(editId.getText().toString());
            c = bd.obtenirUsuari(id);
            if (c.getCount() != 0) {
                Toast.makeText(this, "ID: " + c.getString(0) + "\n" + "Nom: " +
                                c.getString(1) + "\n Nickname: " + c.getString(2) + "\n Lliga: " + c.getString(3),
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "ID inexistent!",
                        Toast.LENGTH_SHORT).show();
            }
            bd.tanca();
            finish();
        }
    }
}
