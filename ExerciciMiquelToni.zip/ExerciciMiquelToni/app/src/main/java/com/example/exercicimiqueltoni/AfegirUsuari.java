package com.example.exercicimiqueltoni;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

public class AfegirUsuari extends AppCompatActivity implements View.OnClickListener {
    DBInterface bd;
    Button btnAfegir;
    Button btnElegir;
    EditText editNom;
    EditText editNickname;
    EditText editLiga;
    ImageView imatgeLliga;
    ByteArrayOutputStream stream;
    int[] imatges = {R.drawable.bronce, R.drawable.silver, R.drawable.gold, R.drawable.platinum, R.drawable.diamond, R.drawable.master, R.drawable.grandmaster, R.drawable.challenger};
    int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_afegir);
        bd = new DBInterface(this);
        btnAfegir = (Button) findViewById(R.id.btnAfegir);
        btnAfegir.setOnClickListener(this);
        editNom = (EditText) findViewById(R.id.afegirNom);
        editNickname = (EditText) findViewById(R.id.afegirNickname);
        editLiga = (EditText) findViewById(R.id.afegirLiga);
        btnElegir = (Button) findViewById(R.id.buttonLliga);
        btnElegir.setOnClickListener(this);
        imatgeLliga = (ImageView) findViewById(R.id.imageView);
    }

    public void onClick(View v) {
        if(v == btnElegir)
        {
            if (i == imatges.length - 1 )
            {
                imatgeLliga.setImageResource(imatges[i]);
                i = 0;
            }
            else {
                imatgeLliga.setImageResource(imatges[i]);
                i++;
            }
        }

        if (v == btnAfegir) {
            BitmapDrawable drawable = (BitmapDrawable) imatgeLliga.getDrawable();
            Bitmap bitmap = drawable.getBitmap();
            String imgString = Base64.encodeToString(getBytesFromBitmap(bitmap),
                    Base64.NO_WRAP);
            bd = new DBInterface(this);
            bd.obre();
            if (bd.insereixUsuari(editNom.getText().toString(),
                    editNickname.getText().toString(), editLiga.getText().toString()) != -1) {
                Toast.makeText(this, "Afegit correctament",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error a l’afegir",
                        Toast.LENGTH_SHORT).show();
            }
            bd.tanca();
            finish();
        }
    }
    public byte[] getBytesFromBitmap(Bitmap bitmap) {
        stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        byte[] bitmapmap = stream.toByteArray();
        imatgeLliga.setImageBitmap(bitmap);
        return bitmapmap;
    }
}
