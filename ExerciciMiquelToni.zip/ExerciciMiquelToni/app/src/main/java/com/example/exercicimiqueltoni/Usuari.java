package com.example.exercicimiqueltoni;

public class Usuari {
    int id;
    String nom;
    String nickname;
    String lliga;
    byte [] foto;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getLliga() {
        return lliga;
    }

    public void setLliga(String lliga) {
        this.lliga = lliga;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }
}
