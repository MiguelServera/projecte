package com.example.exercicimiqueltoni;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;

public class AfegirHistorial extends AppCompatActivity implements View.OnClickListener {
    DBInterface bd;
    Button btnAfegir;
    EditText editNickname;
    EditText editKills;
    EditText editDeaths;
    EditText editAssist;
    Spinner champion;
    String[] championsLlista;
    int[] imagenes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_afegir_historial);
        bd = new DBInterface(this);
        editNickname = (EditText) findViewById(R.id.afegirNickname);
        editKills = (EditText) findViewById(R.id.afegirKills);
        editDeaths = (EditText) findViewById(R.id.afegirDeaths);
        editAssist = (EditText) findViewById(R.id.afegirAssist);
        champion = (Spinner) findViewById(R.id.spinner);
        championsLlista = new String[]
                {"Aatrox", "Ahri",
                "Akali",
                "Alistar",
                "Amumu",
                "Anivia",
                "Annie",
                "Aphelios",
                "Ashe",
                "Aurelion Sol",
                "Azir",
                "Bard",
                "Blitzcrank",
                "Brand",
                "Braum",
                "Caitlyn",
                "Camille",
                "Cassiopeia",
                "Cho'gath",
                "Corki",
                "Darius",
                "Diana",
                "Dr. Mundo",
                "Draven",
                "Ekko",
                "Elise",
                "Evelynn",
                "Ezreal",
                "Fiddlesticks",
                "Fiora",
                "Fizz",
                "Galio",
                "Gangplank",
                "Garen",
                "Gnar",
                "Gragas",
                "Graves",
                "Hecarim",
                "Heimerdinger",
                "Illaoi",
                "Irelia",
                "Ivern",
                "Janna",
                "Jarvan IV",
                "Jax",
                "Jayce",
                "Jhin",
                "Jinx",
                "Kai'sa",
                "Kalista",
                "Karma",
                "Karthus",
                "Kassadin",
                "Katarina",
                "Kayle",
                "Kayn",
                "Kennen",
                "Kha'zix",
                "Kindred",
                "Kled",
                "Kog'maw",
                "Leblanc",
                "Lee Sin",
                "Leona",
                "Lissandra",
                "Lucian",
                "Lulu",
                "Lux",
                "Maestro Yi",
                "Malphite",
                "Malzahar",
                "Maokai",
                "Miss Fortune",
                "Mordekaiser",
                "Morgana",
                "Nami",
                "Nasus",
                "Nautilus",
                "Neeko",
                "Nidalee",
                "Nocturne",
                "Nunu & Willump",
                "Olaf",
                "Orianna",
                "Ornn",
                "Pantheon",
                "Poppy",
                "Pyke",
                "Qiyana",
                "Quinn",
                "Rakan",
                "Rammus",
                "Rek'sai",
                "Renekton",
                "Rengar",
                "Riven",
                "Rumble",
                "Ryze",
                "Sejuani",
                "Senna",
                "Sett",
                "Shaco",
                "Shen",
                "Shyvana",
                "Singed",
                "Sion",
                "Sivir",
                "Skarner",
                "Sona",
                "Soraka",
                "Swain",
                "Sylas",
                "Syndra",
                "Tahm Kench",
                "Taliyah",
                "Talon",
                "Taric",
                "Teemo",
                "Thresh",
                "Tristana",
                "Trundle",
                "Tryndamere",
                "Twisted Fate",
                "Twitch",
                "Udyr",
                "Urgot",
                "Varus",
                "Vayne",
                "Veigar",
                "Vel'koz",
                "Vi",
                "Viktor",
                "Vladimir",
                "Volibear",
                "Warwick",
                "Wukong",
                "Xayah",
                "Xerath",
                "Xin Zhao",
                "Yasuo",
                "Yorick",
                "Yuumi",
                "Zac",
                "Zed",
                "Ziggs",
                "Zilean",
                "Zoe",
                "Zyra",
        };
        imagenes = new int[]{R.drawable.aatrox, R.drawable.ahri, R.drawable.akali, R.drawable.alistar, R.drawable.amumu, R.drawable.anivia,R.drawable.annie,R.drawable.aphelios,R.drawable.ashe, R.drawable.aurelion, R.drawable.azir, R.drawable.bardo, R.drawable.blitz, R.drawable.brand, R.drawable.braum, R.drawable.cait, R.drawable.camille, R.drawable.cass, R.drawable.cho, R.drawable.corki, R.drawable.darius, R.drawable.diana, R.drawable.mundo, R.drawable.draven, R.drawable.ekko, R.drawable.elise, R.drawable.evelynn, R.drawable.ezreal, R.drawable.fiddle, R.drawable.fiora, R.drawable.fizz, R.drawable.galio, R.drawable.gangplank, R.drawable.garen, R.drawable.gnar, R.drawable.gragas, R.drawable.graves, R.drawable.hecarim, R.drawable.heimerdinger, R.drawable.illaoi, R.drawable.irelia, R.drawable.ivern, R.drawable.janna, R.drawable.jarvam, R.drawable.jax, R.drawable.jayce, R.drawable.jhin, R.drawable.jinx, R.drawable.kaisa, R.drawable.kalista, R.drawable.karma, R.drawable.kharthus, R.drawable.kassawin, R.drawable.katarina, R.drawable.kayle, R.drawable.kayn, R.drawable.kennen, R.drawable.khazix, R.drawable.kindred, R.drawable.kled, R.drawable.kog, R.drawable.leblanc, R.drawable.leesin, R.drawable.leona, R.drawable.lissandra, R.drawable.lucian, R.drawable.lulu, R.drawable.lux, R.drawable.masteryi, R.drawable.malphite, R.drawable.malzahar, R.drawable.maokai, R.drawable.missfortune, R.drawable.mordekaiser, R.drawable.morgana, R.drawable.nami, R.drawable.nasus, R.drawable.nautilus, R.drawable.neeko, R.drawable.nidalee, R.drawable.nocturne, R.drawable.nunu, R.drawable.olaf, R.drawable.orianna, R.drawable.ornn, R.drawable.panth, R.drawable.poppy, R.drawable.pyke, R.drawable.qiyana, R.drawable.quinn, R.drawable.rakan, R.drawable.rammus, R.drawable.reksai, R.drawable.renekton, R.drawable.rengar, R.drawable.riven, R.drawable.rumble,R.drawable.ryze, R.drawable.sejuani, R.drawable.senna, R.drawable.sett, R.drawable.shaco, R.drawable.shen, R.drawable.shyvana, R.drawable.singed, R.drawable.sion, R.drawable.sivir, R.drawable.skarner, R.drawable.sona, R.drawable.soraka, R.drawable.swain, R.drawable.sylas
        , R.drawable.syndra, R.drawable.tahm, R.drawable.taliyah, R.drawable.talon, R.drawable.taric, R.drawable.teemo, R.drawable.thresh, R.drawable.tristana, R.drawable.trundle, R.drawable.tryndamere, R.drawable.twitch
        , R.drawable.twitch, R.drawable.udyr, R.drawable.urgot, R.drawable.varus, R.drawable.vayne, R.drawable.veigar, R.drawable.velkoz, R.drawable.vi, R.drawable.viktor, R.drawable.vladimir, R.drawable.volibear, R.drawable.warwick, R.drawable.wukong, R.drawable.xayah, R.drawable.xerath, R.drawable.xin, R.drawable.yasuo, R.drawable.yorick, R.drawable.yuumi, R.drawable.zac, R.drawable.zed, R.drawable.ziggs, R.drawable.zilean, R.drawable.zoe, R.drawable.zyra};
                elegirChampion();
    }

    public void elegirChampion()
    {
        champion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(parent.getContext(), "Selected: " + position+" "+ championsLlista[position], Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        CustomAdapter arrayAdapter = new CustomAdapter(getApplicationContext(), imagenes, championsLlista);
        champion.setAdapter(arrayAdapter);
    }

    public void onClick(View v)
    {/*
        if (v == btnAfegir) {
            bd = new DBInterface(this);
            bd.obre();
            if (bd.insereixHistorial(edit.getText().toString(),
                    editNom.getText().toString(), editKills.getText().toString(), editDeaths.toString()) != -1) {
                Toast.makeText(this, "Afegit correctament",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error a l’afegir",
                        Toast.LENGTH_SHORT).show();
            }
            bd.tanca();
            finish();
        }*/
    }
}

