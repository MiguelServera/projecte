package com.example.exercicimiqueltoni;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DBInterface {
    //Declaració de constants
    public static final String CLAU_ID = "_id";
    public static final String CLAU_NOM = "nom";
    public static final String CLAU_NICKNAME = "nickname";
    public static final String CLAU_LLIGA = "lliga";
    public static final String CLAU_FOTO = "foto";
    public static final String CLAU_ID2 = "_id2";
    public static final String CLAU_NICKNAME2 = "nickname2";
    public static final String CLAU_LLIGA2 = "lliga2";
    public static final String CLAU_KILLS = "kills";
    public static final String TAG = "DBInterface";
    public static final String BD_NOM = "BDUsuaris";
    public static final String BD_TAULA = "usuaris";
    public static final int VERSIO = 1;
    public static final String BD_CREATE ="create table " + BD_TAULA + "( " + CLAU_ID + " integer primary key autoincrement, " + CLAU_NOM +" text not null, " + CLAU_NICKNAME + " text, " + CLAU_LLIGA + " text);";
    String[] allColumnsUsuaris = {CLAU_ID, CLAU_NOM, CLAU_NICKNAME, CLAU_LLIGA};
    private final Context context;
    private AjudaDB ajuda;
    private SQLiteDatabase bd;

    public DBInterface(Context con) {
        this.context = con;
        ajuda = new AjudaDB(context);
    }

    public DBInterface obre() throws SQLException {
        bd = ajuda.getWritableDatabase();
        return this;
    }
    //Tanca la Base de dades
    public void tanca() {
        ajuda.close();
    }

    //Insereix un contacte
    public long insereixUsuari(String nom, String nickname, String lliga) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(CLAU_NOM, nom);
        initialValues.put(CLAU_NICKNAME, nickname);
        initialValues.put(CLAU_LLIGA, lliga);
        return bd.insert(BD_TAULA ,null, initialValues);
    }

    //Esborra un contacte
    public boolean esborraUsuari(long IDFila) {
        return bd.delete(BD_TAULA, CLAU_ID + " = " + IDFila, null) > 0;
    }

    //Retorna un contacte
    public Cursor obtenirUsuari(long IDFila) throws SQLException {
        Cursor mCursor = bd.query(true, BD_TAULA, new String[] {CLAU_ID,
                        CLAU_NOM,CLAU_NICKNAME,CLAU_LLIGA,CLAU_FOTO},CLAU_ID + " = " + IDFila, null, null, null, null,
                null);
        if(mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    public ArrayList<Usuari> obtenirTotsElsUsuaris()
    {
        ArrayList<Usuari> usuaris = new ArrayList<Usuari>();
        Cursor cursor = bd.query(BD_TAULA, allColumnsUsuaris, null, null, null, null, CLAU_NOM + " DESC");
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Usuari usuari = cursorToUsuari(cursor);
            usuaris.add(usuari);
            cursor.moveToNext();
        }

        cursor.close();
        return usuaris;
    }

    private Usuari cursorToUsuari(Cursor cursor)
    {
        Usuari usuari = new Usuari();
        usuari.setId(cursor.getInt(0));
        usuari.setNom(cursor.getString(1));
        usuari.setNickname(cursor.getString(2));
        usuari.setLliga(cursor.getString(3));
        return usuari;
    }
    //Modifica un contacte
    public boolean actualitzarUsuari(long IDFila, String nom, String nickname) {
        ContentValues args = new ContentValues();
        args.put(CLAU_NOM, nom);
        args.put(CLAU_NICKNAME, nickname);
        return bd.update(BD_TAULA, args, CLAU_ID + " = " + IDFila, null) > 0;
    }
}
