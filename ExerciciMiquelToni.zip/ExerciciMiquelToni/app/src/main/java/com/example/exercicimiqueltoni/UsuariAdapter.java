package com.example.exercicimiqueltoni;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class UsuariAdapter extends ArrayAdapter<Usuari> {
    private Context context;
    private List<Usuari> llistaUsuari;
    //constructor
    public UsuariAdapter(Context context, int resource, ArrayList<Usuari> objects) {
        super(context, resource, objects);
        this.context = context;
        this.llistaUsuari = objects;
    }
        //agafam el Joc per posició a l'Array
        public View getView(int position, View convertView, ViewGroup parent)
        {
            Usuari usuari = llistaUsuari.get(position);
            //agafam "l'inflater" per "inflar" el layout per a cada item
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            View view = inflater.inflate(R.layout.llista_principal, null);
            TextView id = (TextView) view.findViewById(R.id.textId);
            TextView nom = (TextView) view.findViewById(R.id.textNom);
            TextView nickname = (TextView) view.findViewById(R.id.textNickname);
            TextView lliga = (TextView) view.findViewById(R.id.textLliga);

            id.setText(usuari.getId());
            nom.setText(usuari.getNom());
            nickname.setText(usuari.getNickname());
            lliga.setText(usuari.getLliga());
            return view;
    }
}
