package com.example.exercicimiqueltoni;

import android.app.ListActivity;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ObtenirLlista extends ListActivity {
    ArrayList<Usuari> llistaUsuari;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dades_llista);
        DBInterface bd;
        bd = new DBInterface(this);
        bd.obre();
        llistaUsuari = bd.obtenirTotsElsUsuaris();
        bd.tanca();
        UsuariAdapter adapter = new UsuariAdapter(this, R.layout.llista_principal, llistaUsuari);
        ListView lw = (ListView) findViewById(R.id.list);
        lw.setAdapter(adapter);
    }
}
