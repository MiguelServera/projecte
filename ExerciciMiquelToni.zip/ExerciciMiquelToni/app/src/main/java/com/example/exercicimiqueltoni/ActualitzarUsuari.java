/*package com.example.exercicimiqueltoni;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActualitzarUsuari extends AppCompatActivity implements View.OnClickListener {
    DBInterface bd;
    Button btnActualitzar;
    EditText editID;
    EditText editNickname;
    EditText editNom;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actualitzar);
        bd = new DBInterface(this);
        btnActualitzar = (Button) findViewById(R.id.btnActualitzar);
        btnActualitzar.setOnClickListener(this);
        editID = (EditText) findViewById((R.id.afegirNom));
        editNom = (EditText) findViewById((R.id.editText3));
        editNickname = (EditText) findViewById((R.id.afegirNickname));
    }
    @Override
    public void onClick(View v) {
        if (v == btnActualitzar) {
            long id;
            bd = new DBInterface(this.getApplicationContext());
            bd.obre();
            id = Long.parseLong(editID.getText().toString());
            boolean result = bd.actualitzarUsuari(id,
                    editNom.getText().toString(), editNickname.getText().toString());
            if (result)
                Toast.makeText(this, "Element modificat",
                        Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "No s’ha pogut modificar l’element",
                        Toast.LENGTH_SHORT).show();
            bd.tanca();
            finish();
        }
    }
}
*/