package com.example.exercicimiqueltoni;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.exercicimiqueltoni.DBInterface;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnAfegir, btnAfegir2, btnObtenir, btnObtenirTots, btnActualitzar,
            btnEsborrar;
    DBInterface bd;
    String editNom = "Miguel";
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bd = new DBInterface(this);
        //Listeners dels botons
        btnAfegir = (Button) findViewById(R.id.btnAfegir);
        btnAfegir.setOnClickListener(this);
        btnAfegir2 = (Button) findViewById(R.id.btnAfegir2);
        btnAfegir2.setOnClickListener(this);
        btnObtenirTots = (Button) findViewById(R.id.btnObtenirTots);
        btnObtenirTots.setOnClickListener(this);
        btnObtenir = (Button) findViewById(R.id.btnObtenir);
        btnObtenir.setOnClickListener(this);
        btnEsborrar = (Button) findViewById(R.id.btnEsborrar);
        btnEsborrar.setOnClickListener(this);
        btnActualitzar = (Button) findViewById(R.id.btnActualitzar);
        btnActualitzar.setOnClickListener(this);
        img = (ImageView) findViewById(R.id.imageView3);
        img.setImageResource(R.drawable.bronce);
        bd.obre();
        bd.tanca();
    }

    public void onClick(View v) {
        if (v == btnActualitzar)
        {
            //startActivity(new Intent(v.getContext(),ActualitzarUsuari.class));
        }

        else if (v == btnAfegir)
        {
            startActivity(new Intent(v.getContext(),AfegirUsuari.class));
        }

        else if (v == btnEsborrar) {
            //startActivity(new Intent(v.getContext(),EsborrarUsuari.class));        }
        }
        else if (v == btnObtenir)
        {
            startActivity(new Intent(v.getContext(),ObtenirUsuari.class));
        }

        else if (v == btnObtenirTots)
        {
            startActivity(new Intent(v.getContext(),ObtenirLlista.class));
        }

        else if (v == btnAfegir2)
        {
            startActivity(new Intent(v.getContext(), AfegirHistorial.class));
        }
    }
}